/*
 * gpio.c
 *
 *  Created on: Dec 18, 2025
 *      Author: mukht
 */

#include "gpio.h"

#define GPIOAEN (1U<<0)

void gpio_init(){

	RCC_AHB1ENR |= GPIOAEN;

	GPIOA_MODER &= ~(1u<<11);
	GPIOA_MODER |= (1u<<10);

	GPIOA_ODR |=  (1U<<5);

}


void gpio_ld2_on(){
	GPIOA_ODR |=  (1U<<5);  // GPIOA5
}


void gpio_ld2_off(){
	GPIOA_ODR &=  ~(1U<<5);  // GPIOA5
}



