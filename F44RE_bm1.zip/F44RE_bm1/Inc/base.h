/*
 * base.h
 *
 *  Created on: Dec 18, 2025
 *      Author: mukht
 */

#ifndef BASE_H_
#define BASE_H_

#define PERIPHERAL_BASE 0x40000000

#define AHB1_PERIPHERAL_OFFSET 0x00020000	// same as GPIOA
#define AHB1_PERIPHERAL			(PERIPHERAL_BASE + AHB1_PERIPHERAL_OFFSET)



#define RCC_PERIPHERAL_OFFSET	0x00023800
#define RCC_PERIPHERAL			(PERIPHERAL_BASE + RCC_PERIPHERAL_OFFSET)



#endif /* BASE_H_ */
