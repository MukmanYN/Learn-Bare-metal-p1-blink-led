/*
 * gpio.h
 *
 *  Created on: Dec 18, 2025
 *      Author: mukht
 */
#include "base.h"
#ifndef GPIO_H_
#define GPIO_H_


#define GPIOA_MODER_OFFSET	 0x00
#define GPIOA_MODER			(*(volatile unsigned int *)(AHB1_PERIPHERAL + GPIOA_MODER_OFFSET))


#define GPIOA_ODR_OFFSET	 0x14
#define GPIOA_ODR 		(*(volatile unsigned int *)(AHB1_PERIPHERAL + GPIOA_ODR_OFFSET))

#define RCC_AHB1ENR_OFFSET	0x30
#define RCC_AHB1ENR		(*(volatile unsigned int *)(RCC_PERIPHERAL + RCC_AHB1ENR_OFFSET))


void gpio_init();
void gpio_ld2_on();
void gpio_ld2_off();
#endif /* GPIO_H_ */
